package com.nopalyer.navigationdrawer.electrical;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.nopalyer.navigationdrawer.R;

public class eeaboutus extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ee_eeaboutus);
    }
}
